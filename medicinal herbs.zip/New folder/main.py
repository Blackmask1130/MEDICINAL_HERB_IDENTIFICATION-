import streamlit as st
import tensorflow as tf
import numpy as np

#Tensorflow Model Prediction
def model_prediction(test_image):
    model = tf.keras.models.load_model("trained_model.keras")
    image = tf.keras.preprocessing.image.load_img(test_image,target_size=(256,256))
    input_arr = tf.keras.preprocessing.image.img_to_array(image)
    input_arr = np.array([input_arr]) #convert single image to batch
    predictions = model.predict(input_arr)
    return np.argmax(predictions) #return index of max element

#Sidebar
st.sidebar.title("Dashboard")
app_mode = st.sidebar.selectbox("Select Page",["Home","About","Herbs Recognition"])

#Main Page
if(app_mode=="Home"):
    st.header("MEDICINAL HERB IDENTIFICATION SYSTEM")
    image_path = "home_page.jpeg"
    st.image(image_path,use_column_width=True)
    st.markdown("""
    Welcome to the Medicinal Herb Identification System! 🌿🔍
    
    Our mission is to help in identifying plant herbs efficiently. Upload an image of a plant, and our system will analyze it to detect any signs of medicinal value. Together, let's protect our crops and ensure a healthier harvest!

    ### How It Works
    1. **Upload Image:** Go to the **Image Recognition** page and upload an image of a plant with suspected medicinal value.
    2. **Analysis:** Our system will process the image using advanced algorithms to identify potential herbal value.
    3. **Results:** View the results and recommendations for further action.

    ### Why Choose Us?
    - **Accuracy:** Our system utilizes state-of-the-art machine learning techniques for accurate herbal detection.
    - **User-Friendly:** Simple and intuitive interface for seamless user experience.
    - **Fast and Efficient:** Receive results in seconds, allowing for quick decision-making.

    ### Get Started
    Click on the **Image Recognition** page in the sidebar to upload an image and experience the power of our Plant Disease Recognition System!

    ### About Us
    Learn more about the project, our team, and our goals on the **About** page.
    """)

#About Project
elif(app_mode=="About"):
    st.header("About")
    video_file = open("100 Medicinal Plants Names And Their Uses _ Blissed Zone.mp4", "rb")
    video_bytes = video_file.read()
    st.video(video_bytes)
    st.markdown("""
                #### About Dataset
                This dataset is recreated using offline augmentation from the original dataset.The original dataset can be found on this github repo.
                This dataset consists of about 1500 rgb images of healthy and herbal value leaves which is categorized into 126 different classes.The total dataset is divided into  ratio of training and validation set preserving the directory structure.
                A new directory containing 1000 test images is created later for prediction purpose.
                #### Content
                1. train (1500 images)
                2. test (1000 images)
                3. validation (1500 images)

                """)

#Prediction Page
elif(app_mode=="Herbs Recognition"):
    st.header("Herbs Recognition")
    test_image = st.file_uploader("Choose an Image:")
    if(st.button("Show Image")):
        st.image(test_image,width=4,use_column_width=True)
     #Predict button
    if(st.button("Predict")):
        st.snow()
        st.write("Our Prediction")
        result_index = model_prediction(test_image)
        #Reading Labels
        class_name = ['Acacia Nilotica','Achillea_millefolium','Actaea_racemosa','Adusa or Vasaka',
                      'Aesculus_hippocastanum','Aesthetic_bunch_of_fenugreek_greens','Ageratina_altissima',
                      'Alcea_rosea','Alisma_plantago-aquatica','Aloe Vera','Althaea_officinalis_Prague',
                      'Amorphophallus_konjac_(fruit)_','Anise hyssop','Apium_graveolens','ArctiumLappa',
                      'Arnica_montana','Astragalus_membranaceus','Augentrost','Bark Cinnamon','Berberis',
                      'Bilberry','Bitter_orange_-_Citrus_aurantium','Blessed thistle','Blé_tendre_hiver_(GHAYTA)_AO-5-cliche_Jean_Weber',
                      'Blue_Snakeweed','Borage','Boswellia_sacra','Burdock','Calendula','Cannabis','Capsicum_annuum',
                      'Carica_papaya',"Cat's claw leaf",'Catha_edulis','Cayaponia_espelina_','Cayenne peppers',
                      'CentaureaCyanus','Chaya leaf','Chickweed','Cilantro','Cinchona.pubescens','Citrus_trifoliata',
                      'Cluster_of_Reichardia_tingitana','Cnicus_benedictus_flor','Common Hepatica-Anemone hepatica',
                      'Common_sea-buckthorn_-_Sanddorn','Composite','Cordyceps','Coulon-Angélique','Crataegus,_various_species,_fruit',
                      'Cypripedium_parviflorum_Orchi','Damiana plant leaves','Dandelion','Digitalis_lanata._Wooly_Foxglove',
                      'Diploclisia_glaucescens_Wynaad','Dita','Dong quai','DrumstickFlower','Echinacea_purpurea',
                      'Echinopsis_pachanoi','Elderberry','Eleuthero','Ephedra_sinica_alexlomas','Equisetum_arvense_foliage',
                      'Eriodictyoncrassifolium','Erythroxylum_coca_','Euphorbia_hirta_','Evening-Primrose',
                      'Fennel','Fenugreek plant','Feverfew','Frangula-alnus-fruits','Gardenology','Ginkgo',
                      'Ginseng','Goldenseal plant','Gotu kola leaves','Grape_vines_','Green tea','Holy Basil (Tulsi)plant leaves',
                      'Hops','Horse chestnut leaves','Horsetail plant','Hyssopus_officinalis','Jasmine leaves',
                      'Kaldari_Stellaria','Kava leaves','Kharagola','Lavender plant','Lemon Balm','Maca',
                      'Milk thistle','Moringa plant','Mullein leaves','Mustard plant','Neem plant','Nettle leaves',
                      'Oregano leaves','Rosa majalis leaf','Rosemary','Sage herb','Saw Palmetto','Schisandra','Senna_auriculata',
                      'Stevia plant','Tarragon leaves','Turmeric plant leaves','Valvet bean','Wild yam leaves',
                      'bitter_melon','black-seed-nigella-sativa-plant-blue-flower','cardamom-plant','cassava plant',
                      'catnip','chamomile-flowering-','chia','clove-plant','comfrey plant leaves','cranberry plant',
                      'cumin leaves-plant','eucalyptus plant','garlic-stems-leaves','hawthorn leaves','licorice',
                      'red clover','st-johns-wort-plant-']

        st.success("Model is Predicting it's a {} .Berries have been used in traditional medicine for centuries to treat digestive issues, infections, and skin conditions. They contain several beneficial compounds, most notably berberine, which acts as an antioxidant and may help manage conditions like diabetes, fight dental infections, and treat acne".format(class_name[result_index])) 

    